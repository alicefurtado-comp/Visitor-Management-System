from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import csv
import os
from datetime import datetime

root=Tk()
root.configure(bg="#F1F5F9")
root.title("VISITOR MANAGEMENT APPLICATION")
root.geometry("900x700")

#give CSV file name
file_name=("VISITOR--LOG123.csv")

#W CSV
if not os.path.exists(file_name):
     with open("VISITOR--LOG123.csv","w",newline="")as file:
        writer=csv.writer(file)
        writer.writerow(["Name","Contact","Purpose","Host","Status","CheckIn","CheckOut"])

#LOGO FRAME
top_frame = Frame(root, bg="#0F172A", height=100)
top_frame.pack(fill=X)


title = Label(top_frame,
              text="VISITOR MANAGEMENT SYSTEM",
              bg="#0F172A",
              fg="white",
              font=("times new roman", 24, "bold"))
title.pack(side=LEFT)

#MAIN BODY
body_frame = Frame(root, bg="#F1F5F9")
body_frame.pack(fill=BOTH, expand=True)

#LEFT FRAME
left_frame = Frame(body_frame,
                   bg="white",
                   width=300,
                   bd=1,
                   relief="solid")
left_frame.pack(side=LEFT, fill=Y, padx=20, pady=20)
left_frame.pack_propagate(False)

#RIGHT FRAME
right_frame = Frame(body_frame,
                    bg="white",
                    bd=1,
                    relief="solid")
right_frame.pack(side=LEFT, fill=BOTH, expand=True, padx=20, pady=20)

# LEFT FORM TITLE
Label(left_frame, text="VISITOR REGISTRATION",
      bg="white",
      font=("Arial", 14, "bold")).pack(pady=15)

def make_label(text):
    return Label(left_frame,
                 text=text,
                 bg="white",
                 fg="#1E293B",
                 font=("Arial",10,"bold"))

# VISITOR NAME
make_label("Visitor Name").pack(anchor="w", padx=5)
name_entry = Entry(left_frame, font=("Arial", 11))
name_entry.pack(fill=X, pady=(5,15), ipady=5)

# CONTACT
make_label("Contact").pack(anchor="w", padx=5)
contact_entry = Entry(left_frame, font=("Arial", 11))
contact_entry.pack(fill=X, pady=(5,15), ipady=5)

# PURPOSE
make_label("Purpose of Visit").pack(anchor="w", padx=5)
purpose = ttk.Combobox(left_frame, font=("Arial", 11), state="readonly",
                        values=[
                            "Interview","Internship","Meeting",
                            "Client Visit","Official Work","Delivery"
                        ])
purpose.pack(fill=X, pady=(5,15), ipady=4)

# HOST
make_label("Host Name").pack(anchor="w", padx=5)
host = ttk.Combobox(left_frame, font=("Arial", 11), state="readonly",
                    values=["HR","Manager","Director","Admin","Reception","Employee"])
host.pack(fill=X, pady=(5,15), ipady=4)

#FUNCTION
def submit():
    Name = name_entry.get()
    Contact = contact_entry.get()
    Purpose = purpose.get()
    Host = host.get()

    if Name=="" or Contact=="" or Purpose=="" or Host=="":
       messagebox.showerror("Error","All fields required!")
       return

    if not Contact.isdigit():
       messagebox.showerror("Error","Contact number must contain only digits!")
       return

    if len(Contact)!=10:
       messagebox.showerror("Error","Please enter a valid 10 digit number!")
       return  

    Status="Pending"
    CheckIn=datetime.now().strftime("%d-%m-%Y %H:%M")
    CheckOut=""

    with open("VISITOR--LOG123.csv","a",newline="")as file:
        writer=csv.writer(file)
        writer.writerow([Name,Contact,Purpose,Host,Status,CheckIn,CheckOut])

    messagebox.showinfo("Success","Form Stored Successfully!")

    name_entry.delete(0,END)
    contact_entry.delete(0,END)
    purpose.set("")
    host.set("")

    load_data()

#SUBMIT BUTTON
Button(left_frame,
       text="REGISTER",
       command=submit,
       bg="#2563EB",
       fg="white",
       height=2).pack(fill=X, pady=15)

#TABLE
style = ttk.Style()
style.configure("Treeview",
                font=("Arial", 10),
                rowheight=28)

style.configure("Treeview.Heading",
                font=("Arial", 11, "bold"))

#RIGHT SIDE TABLE
Label(right_frame,
      text="VISITOR RECORDS",
      bg="white",
      fg="#1E293B",
      font=("Arial", 14, "bold")).pack()

columns=("Name","Contact","Purpose","Host","Status","CheckIn","CheckOut")

tree=ttk.Treeview(right_frame,columns=columns,show="headings",height=15)

for col in columns:
    tree.heading(col, text=col)
    tree.column(col, width=120, anchor="center")

tree.pack(fill=BOTH, expand=True)

#LOAD DATA
def load_data():
    tree.delete(*tree.get_children())

    with open(file_name,"r") as file:
         reader=csv.reader(file)
         next(reader)

         for row in reader:
            tree.insert("",END,values=row)

load_data()

#UPDATE STATUS 
def update_status(new_status):
    selected=tree.focus()

    if not selected:
        messagebox.showerror("Error","Visitor not selected!")
        return

    values=list(tree.item(selected,"values"))
    values[4]=new_status

    rows=[]
    with open(file_name,"r") as file:
        reader=csv.reader(file)
        rows=list(reader)

    for i in range(1, len(rows)):
        if rows[i][0] == values[0] and rows[i][1] == values[1]:
            rows[i] = values
            break

    with open(file_name,"w",newline="")as file:
        writer=csv.writer(file)
        writer.writerows(rows)

    load_data()
    messagebox.showinfo("Success",f"Status updated to {new_status}")

#CHECKOUT 
def checkout_visitor():
    selected=tree.focus()

    if not selected:
        messagebox.showerror("Error","Visitor not selected!")
        return

    values=list(tree.item(selected,"values"))

    checkout_time=datetime.now().strftime("%d-%m-%Y %H:%M")
    values[6]=checkout_time

    rows=[]
    with open(file_name,"r") as file:
        reader=csv.reader(file)
        rows=list(reader)

    for i in range(1, len(rows)):
        if rows[i][0] == values[0] and rows[i][1] == values[1]:
            rows[i] = values
            break

    with open(file_name,"w",newline="")as file:
        writer=csv.writer(file)
        writer.writerows(rows)

    load_data()
    messagebox.showinfo("Success","Check-Out recorded!")

#GENERATE PASS 
def generate_pass():
    selected=tree.focus()

    if not selected:
        messagebox.showerror("Error","Visitor must be selected!")
        return
    
    values=list(tree.item(selected,"values"))
    
    if values[4]!=("Approved"):
        messagebox.showerror("Error","Only approved visitors get pass!")
        return
    
    pass_window=Toplevel(root)
    pass_window.title("VISITOR PASS")
    pass_window.geometry("500x450")

    Label(pass_window, text="VISITOR PASS", font=("Arial",24,"bold")).pack(pady=14)

    Label(pass_window,text=f"Name:{values[0]}").pack()
    Label(pass_window,text=f"Contact:{values[1]}").pack()
    Label(pass_window,text=f"Purpose:{values[2]}").pack()
    Label(pass_window,text=f"Host:{values[3]}").pack()
    Label(pass_window,text=f"Status:{values[4]}").pack()
    Label(pass_window,text=f"CheckIn:{values[5]}").pack()

#BUTTONS
button_frame = Frame(root, bg="#F1F5F9")
button_frame.pack(pady=15, fill=X)

def make_btn(text, color, cmd):
    return Button(button_frame,
                  text=text,
                  bg=color,
                  fg="white",
                  font=("Arial", 11, "bold"),
                  width=15,
                  height=2,
                  cursor="hand2",
                  command=cmd)

make_btn("Approve", "#22C55E",
         lambda: update_status("Approved")).pack(side=LEFT, padx=10)

make_btn("Reject", "#EF4444",
         lambda: update_status("Rejected")).pack(side=LEFT, padx=10)

make_btn("Generate Pass", "#8B5CF6",
         generate_pass).pack(side=LEFT, padx=10)

make_btn("Check Out", "#0EA5E9",
         checkout_visitor).pack(side=LEFT, padx=10)

root.mainloop()